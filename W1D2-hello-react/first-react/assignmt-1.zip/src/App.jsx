import './App.css';

function App() {


  return (
    <>
      <div>
        <h1 className='red'>hello react</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum, nesciunt.</p>

      </div>
    </>
  );
}

export default App;
